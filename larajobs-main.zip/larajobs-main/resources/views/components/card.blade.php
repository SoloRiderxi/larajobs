{{-- This is for all of the cards we're using --}}
<div class="bg-blue-100 border border-gray-200 rounded p-6">
	{{$slot}}
</div>